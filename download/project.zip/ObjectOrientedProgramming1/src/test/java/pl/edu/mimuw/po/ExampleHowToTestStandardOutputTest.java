package pl.edu.mimuw.po;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ExampleHowToTestStandardOutputTest {
	
	private ByteArrayOutputStream baos = new ByteArrayOutputStream(1000);
	
	@Before
	public void setUp() throws Exception {
	    System.setOut(new PrintStream(baos));
	}

	@After
	public void tearDown() throws Exception {
		System.setOut(null);
	}

	@Test
	public void test() {
		ExampleHowToTestStandardOutput.main();
		Assert.assertEquals("data", baos.toString());
	}
}
 