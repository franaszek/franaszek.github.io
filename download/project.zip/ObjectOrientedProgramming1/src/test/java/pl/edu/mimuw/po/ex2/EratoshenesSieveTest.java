package pl.edu.mimuw.po.ex2;

import org.junit.Assert;
import org.junit.Test;

public class EratoshenesSieveTest {
	
	private EratosthenesSieve sieve;

	@Test
	public void test4() {
		Assert.assertEquals(3, sieve.findMaxPrimeNumber(4));
	}
	

	@Test
	public void test11() {
		Assert.assertEquals(11, sieve.findMaxPrimeNumber(11));
	}
	

	@Test
	public void test97() {
		Assert.assertEquals(97, sieve.findMaxPrimeNumber(100));
	}

	
}
