package pl.edu.mimuw.po;

public class ExampleHowToTestStandardOutput {

	public static void main(String... args) {
		System.out.print("data");
	}
}
