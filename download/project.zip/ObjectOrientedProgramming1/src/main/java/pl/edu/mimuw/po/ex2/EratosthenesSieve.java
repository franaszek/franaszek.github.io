package pl.edu.mimuw.po.ex2;

public class EratosthenesSieve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public int findMaxPrimeNumber(int n) {
		// TODO implement this method
		return -1;
	}

}
