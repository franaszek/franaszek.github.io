package pl.edu.mimuw.po.ex2;

public class Program {

}
